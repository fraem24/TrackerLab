# TrackerLab

Package for detecting features in digital microscopy images.

[Documentation](http://fraem24.github.io/trackerlab)